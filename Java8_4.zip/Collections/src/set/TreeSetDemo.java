package set;

import java.util.Set;
import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {


			Set<String> set = new TreeSet<String>();
			
			set.add("king");
			set.add("tom");
			set.add("adam");
			set.add("brown");
			set.add("don");
			
			System.out.println(set);
			
			
			
			
		

	}

}
