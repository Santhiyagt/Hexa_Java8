
public interface Payment {
	double calBill(double amt);

}
