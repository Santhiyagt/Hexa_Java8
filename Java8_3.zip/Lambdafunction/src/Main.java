
public class Main {
	public static void main(String[] args) {
		double amount = 500.0;
		Payment upi = (amt) -> amt - (amt * 5 / 100);
		Payment cash = (amt) -> amt - (amt * 10 / 100);
		Payment credit = (amt) -> amt - (amt * 4 / 100);
		System.out.println("UPI Payment is " + upi.calBill(amount));
		System.out.println("Cash Payment is " + cash.calBill(amount));
		System.out.println("Credit Card Payment is " + credit.calBill(amount));
	}
}