package spacetrim;

import java.util.ArrayList;

public class Main{
    public static void main(String[] args) {
        ArrayList<Double> salaries = new ArrayList<>();
        salaries.add(50000.0);
        salaries.add(60000.0);
        salaries.add(55000.0);
        salaries.add(70000.0);
        salaries.add(65000.0);
        System.out.println("Original Salary\tUpdated Salary (+5%)");
        for (double salary : salaries) {
            double updatedSalary = salary + (salary * 0.05);
            System.out.printf("%.2f\t\t%.2f%n", salary, updatedSalary);
        }
    }
}
