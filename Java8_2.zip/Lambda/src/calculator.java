
public interface calculator {
	public int  cal(int a, int b);
}
